#include <viennaps.hpp>

using namespace viennaps;

int main(int argc, char *argv[]) {
  // Create your ViennaPS program here
}